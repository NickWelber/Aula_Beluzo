<?php

$p = null;
	$p["pesquisa"] = "time";
	$p["titulo"] = "Time";
	
	
?>