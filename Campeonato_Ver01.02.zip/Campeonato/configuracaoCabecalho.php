<?php
$p["logo"] = "img/logo.png";
$p["alt_logo"] = "Logotipo Campeonato";
    $p["links"][0]["link"] = "campeonato.php";
    $p["links"][0]["label"] = "Campeonatos";
    $p["links"][1]["link"] = "Jogo.php";
    $p["links"][1]["label"] = "Jogos";
    $p["links"][2]["link"] = "time.php";
    $p["links"][2]["label"] = "Times";
    $p["links"][3]["link"] = "jogador.php";
    $p["links"][3]["label"] = "Jogadores"; 
    $p["links"][4]["link"] = "arbitro.php";
    $p["links"][4]["label"] = "Arbitros"; 
?>