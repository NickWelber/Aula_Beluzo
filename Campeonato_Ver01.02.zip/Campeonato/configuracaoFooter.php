<?php
    $p = null;
    $p["botao"] = "#novoTime";
    $p["titulo"] = "Novo Time";
?>