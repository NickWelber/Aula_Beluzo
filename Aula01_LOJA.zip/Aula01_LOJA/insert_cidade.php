<?php
    include "conexao.php";

    $insert = "INSERT INTO cidade(nome_cidade,cod_estado) VALUES (:nc,:cd)";
    $stmt = $conexao->prepare($insert);

    $stmt->bindValue(":nc", $_POST["nome_cidade"]);
    $stmt->bindValue(":cd", $_POST["cod_estado"]);
    $stmt->execute();

    echo "Cidade Inserida no Bancode Dados. <a href='index.php'>Voltar...</a>";
?>