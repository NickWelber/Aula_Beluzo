<?php
    include "menu.php";
    include "conexao.php";
        $select = "SELECT * FROM cidade ORDER BY nome_cidade";
//-- PDOStatement --//
        $stmt = $conexao->prepare($select);
        $stmt->execute();

?>
        <form method="post" name="f" action="insert_loja.php">
            <input type="text" name="razao_social" placeholder="Razão Social..." />
            <input type="text" name="nome_fantasia" placeholder="Nome Fantasia..." />
            <input type="mail" name="email" placeholder="E-mail..." />

            <select name="cod_cidade">
            <option>::Selecione uma Cidade::</option>
        <?php
            while($linha=$stmt->fetch()){
                $cod_estado = $linha["id_cidade"];
                $sigla = $linha["nome_cidade"];
                echo "<option value='$id_cidade'>$nome_cidade</option>";
            }
        ?>
            <button>Enviar</button>
        </form>
    </body>
</html>