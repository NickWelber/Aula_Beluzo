<?php
    include "conexao.php";

    $insert = "INSERT INTO loja(razao_social,nome_fantasia,email,cod_cidade) VALUES (:rs,:nf,:e,:cc)";
    $stmt = $conexao->prepare($insert);

    $stmt->bindValue(":rs", $_POST["razao_social"]);
    $stmt->bindValue(":nf", $_POST["nome_fantasia"]);
    $stmt->bindValue(":e", $_POST["email"]);
    $stmt->bindValue(":cc", $_POST["cod_cidade"]);
    $stmt->execute();

    echo "Loja Inserida no Bancode Dados. <a href='index.php'>Voltar...</a>";
?>