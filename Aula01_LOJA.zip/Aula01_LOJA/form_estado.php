<?php
    include "menu.php";
    include "conexao.php";
?>
        <form method="post" name="f" action="insert_stmt.php">
            <input type="text" name="nome_estado" placeholder="Nome Estado..." />
            <input type="text" name="sigla" placeholder="Sigla Estado..." />
            <button>Enviar</button>
        </form>
    </body>
</html>