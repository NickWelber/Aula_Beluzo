<?php
    include "conexao.php";
    include "menu.php";

    $select = "SELECT * FROM cidade 
                INNER JOIN estado 
                    ON estado.id_estado=cidade.cod_estado";
    $stmt = $conexao->prepare($select);
    $stmt->execute();

    while($linha = $stmt->fetch()){
    //  echo "ID: " .$linha["id_cidade"]. "<br />";
        echo "Nome Cidade: " . $linha["nome_cidade"]. "<br />";
    //  echo "Cod. Estado: " .$linha["cod_estado"]. "<br /><hr />";
        echo "Sigla Estado: " .$linha["sigla"]. "<br /><hr />";
    }
?>