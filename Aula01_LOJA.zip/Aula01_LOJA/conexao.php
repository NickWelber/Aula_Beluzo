<!-- Usar este dados para se conectar no banco de dados 
?php
    $conexao = new POD("$sgbd:host=$local;dbname=$nome_db", $usuario,$senha);
?>
-->

<!-- Usar este dados para se comunicar com o banco de dados -->
<?php
    $sgbd = "mysql";
    $local = "localhost";
    $nome_bd = "loja";
    $usuario = "root";
    $senha = "";

    $conexao = new POD("$sgbd:host=$local;dbname=$nome_db", $usuario,$senha);
?>