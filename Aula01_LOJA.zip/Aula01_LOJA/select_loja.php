<?php
    include "conexao.php";
    include "menu.php";

    $select = "SELECT * FROM loja 
                INNER JOIN cidade 
                    ON cidade.id_cidade=loja.cod_cidade";
    $stmt = $conexao->prepare($select);
    $stmt->execute();

    while($linha = $stmt->fetch()){
    //  echo "ID: " .$linha["id_loja"]. "<br />";
        echo "Razão Social: " . $linha["razao_social"]. "<br />";
        echo "Nome Fantasia: " .$linha["nome_fantasia"]. "<br /><hr />";
        echo "Email: " .$linha["email"]. "<br /><hr />";
        echo "Cidade: " .$linha["nome_cidade"]. "<br /><hr />";
    }
?>