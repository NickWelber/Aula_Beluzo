<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <title>Inicio</title>
    </head>
    <body>

        <ul>
            <legend><h3>Cadastrar</h3></legend>
            <li><a href="form_estado.php">Estado</a></li>
            <li><a href="form_cidade.php">Cidade</a></li>
            <li><a href="form_loja.php">Loja</a></li>
        </ul>
        <ul>
            <legend><h3>Listar</h3></legend>
            <li><a href="select_estado.php">Estado</a></li>
            <li><a href="select_cidade.php">Cidade</a></li>
            <li><a href="select_loja.php">Loja</a></li>
        </ul>       
        <hr />